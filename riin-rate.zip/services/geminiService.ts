
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface MovieMetadata {
  title: string;
  year: number;
  genre: string[];
  type: 'movie' | 'series';
  poster: string;
  sourceUrl?: string;
}

export const searchMovieMetadata = async (query: string): Promise<MovieMetadata | null> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search for detailed information about the movie or series: "${query}". 
      Return the data in a strict JSON format with these exact keys: 
      title (official full name), 
      year (release year as a number), 
      genre (array of strings), 
      type (either "movie" or "series"), 
      poster (a direct URL to the official movie poster or high-quality image).`,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            year: { type: Type.NUMBER },
            genre: { type: Type.ARRAY, items: { type: Type.STRING } },
            type: { type: Type.STRING, enum: ["movie", "series"] },
            poster: { type: Type.STRING },
          },
          required: ["title", "year", "genre", "type", "poster"]
        }
      },
    });

    if (response.text) {
      const data = JSON.parse(response.text.trim());
      // Extract first grounding chunk for source transparency if available
      const sourceUrl = response.candidates?.[0]?.groundingMetadata?.groundingChunks?.[0]?.web?.uri;
      
      return {
        ...data,
        sourceUrl
      };
    }
    return null;
  } catch (error) {
    console.error("Gemini Search Error:", error);
    return null;
  }
};

export const generateMovieReview = async (movieTitle: string): Promise<string> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Give a very brief, 1-sentence catchy summary/review for the movie "${movieTitle}".`,
    });
    return response.text || "";
  } catch {
    return "";
  }
};
