
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Movie, User } from './types';
import { INITIAL_MOVIES } from './constants';
import { MovieCard } from './components/MovieCard';
import { AddMovieForm } from './components/AddMovieForm';
import { DeleteConfirmModal } from './components/DeleteConfirmModal';
import { Login } from './components/Login';
import { CalendarView } from './components/CalendarView';

type FilterType = 'all' | 'movie' | 'series';
type SortType = 'watched' | 'release' | 'rating' | 'title';
type ViewMode = 'grid' | 'calendar';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('riinrate_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [movies, setMovies] = useState<Movie[]>(() => {
    const saved = localStorage.getItem('my_rated_movies');
    return saved ? JSON.parse(saved) : INITIAL_MOVIES;
  });
  
  // UI State
  const [viewMode, setViewMode] = useState<ViewMode>('grid');
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingMovie, setEditingMovie] = useState<Movie | null>(null);
  const [itemToDelete, setItemToDelete] = useState<Movie | null>(null);
  const [filter, setFilter] = useState<FilterType>('all');
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [sortBy, setSortBy] = useState<SortType>('watched');
  
  // Search state with debounce
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearchQuery, setDebouncedSearchQuery] = useState('');
  
  const [isSortDropdownOpen, setIsSortDropdownOpen] = useState(false);
  const [isFilterPanelOpen, setIsFilterPanelOpen] = useState(false);
  
  // Advanced Filter State
  const [minYear, setMinYear] = useState<number>(1900);
  const [maxYear, setMaxYear] = useState<number>(new Date().getFullYear() + 1);
  const [minRating, setMinRating] = useState<number>(0);

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Debounce logic
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedSearchQuery(searchTerm);
    }, 300);

    return () => {
      clearTimeout(handler);
    };
  }, [searchTerm]);

  useEffect(() => {
    localStorage.setItem('my_rated_movies', JSON.stringify(movies));
  }, [movies]);

  useEffect(() => {
    if (user) {
      localStorage.setItem('riinrate_user', JSON.stringify(user));
    } else {
      localStorage.removeItem('riinrate_user');
    }
  }, [user]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsSortDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogin = (username: string) => {
    setUser({ username });
  };

  const handleLogout = () => {
    setUser(null);
  };

  const handleSaveMovie = (movieData: Omit<Movie, 'id'>) => {
    if (editingMovie) {
      setMovies(prev => prev.map(m => m.id === editingMovie.id ? { ...movieData, id: m.id } : m));
    } else {
      const newMovie: Movie = {
        ...movieData,
        id: Math.random().toString(36).substr(2, 9)
      };
      setMovies(prev => [newMovie, ...prev]);
    }
    setIsFormOpen(false);
    setEditingMovie(null);
  };

  const handleQuickRatingChange = (id: string, newRating: number) => {
    setMovies(prev => prev.map(m => m.id === id ? { ...m, rating: newRating } : m));
  };

  const requestDeleteMovie = (movie: Movie) => {
    setItemToDelete(movie);
  };

  const confirmDelete = () => {
    if (itemToDelete) {
      setMovies(prev => prev.filter(m => m.id !== itemToDelete.id));
      setItemToDelete(null);
    }
  };

  const handleEditMovie = (movie: Movie) => {
    setEditingMovie(movie);
    setIsFormOpen(true);
  };

  const handleGenreClick = (genre: string) => {
    setSelectedGenre(genre === selectedGenre ? null : genre);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const resetAdvancedFilters = () => {
    setMinYear(1900);
    setMaxYear(new Date().getFullYear() + 1);
    setMinRating(0);
    setSearchTerm('');
    setSelectedGenre(null);
  };

  const filteredMovies = useMemo(() => {
    return movies
      .filter(m => {
        const matchesType = filter === 'all' || m.type === filter;
        
        // Multi-field fuzzy search
        const searchContent = `${m.title} ${m.genre.join(' ')} ${m.year}`.toLowerCase();
        const searchTokens = debouncedSearchQuery.toLowerCase().trim().split(/\s+/);
        const matchesSearch = searchTokens.every(token => searchContent.includes(token));
        
        const matchesGenre = !selectedGenre || m.genre.includes(selectedGenre);
        const matchesYear = m.year >= minYear && m.year <= maxYear;
        const matchesRating = m.rating >= minRating;
        
        return matchesType && matchesSearch && matchesGenre && matchesYear && matchesRating;
      })
      .sort((a, b) => {
        if (sortBy === 'watched') return b.watchedYear - a.watchedYear;
        if (sortBy === 'release') return b.year - a.year;
        if (sortBy === 'rating') return b.rating - a.rating;
        if (sortBy === 'title') return a.title.localeCompare(b.title);
        return 0;
      });
  }, [movies, filter, debouncedSearchQuery, selectedGenre, sortBy, minYear, maxYear, minRating]);

  const sortLabels: Record<SortType, string> = {
    watched: 'Terbaru Ditonton',
    release: 'Tahun Rilis',
    rating: 'Rating Tertinggi',
    title: 'Judul (A-Z)'
  };

  const hasActiveFilters = searchTerm !== '' || selectedGenre !== null || minYear > 1900 || maxYear < new Date().getFullYear() + 1 || minRating > 0;

  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-[#0a0a0a] pb-24 text-white animate-in fade-in duration-500">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-black/60 backdrop-blur-xl border-b border-white/5 py-6 mb-8">
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <div onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})} className="cursor-pointer">
              <h1 className="text-3xl font-black italic tracking-tighter text-white flex items-center gap-2">
                <span className="text-indigo-500">RIIN</span>RATE
              </h1>
              <p className="text-xs text-white/40 font-medium uppercase tracking-[0.2em] mt-1">Personal Collection</p>
            </div>
            <div className="hidden lg:block h-8 w-px bg-white/10 mx-2"></div>
            
            {/* View Toggle */}
            <div className="hidden md:flex bg-white/5 p-1 rounded-full border border-white/10">
              <button 
                onClick={() => setViewMode('grid')}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold transition-all ${viewMode === 'grid' ? 'bg-indigo-600 text-white shadow-lg' : 'text-white/40 hover:text-white'}`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                  <path d="M5 3a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2V5a2 2 0 00-2-2H5zM5 11a2 2 0 00-2 2v2a2 2 0 002 2h2a2 2 0 002-2v-2a2 2 0 00-2-2H5zM11 5a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2V5zM11 13a2 2 0 012-2h2a2 2 0 012 2v2a2 2 0 01-2 2h-2a2 2 0 01-2-2v-2z" />
                </svg>
                Grid
              </button>
              <button 
                onClick={() => setViewMode('calendar')}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-full text-xs font-bold transition-all ${viewMode === 'calendar' ? 'bg-indigo-600 text-white shadow-lg' : 'text-white/40 hover:text-white'}`}
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clipRule="evenodd" />
                </svg>
                Riwayat
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsFormOpen(true)}
              className="bg-white text-black px-6 py-2.5 rounded-full font-bold flex items-center gap-2 hover:bg-gray-200 transition-all shadow-lg active:scale-95 text-sm"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
              </svg>
              Tambah
            </button>
            <button 
              onClick={handleLogout}
              className="p-2.5 rounded-full bg-white/5 border border-white/10 text-white/40 hover:text-red-400 hover:bg-red-400/10 hover:border-red-400/20 transition-all group"
              title="Keluar"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6">
        {viewMode === 'grid' ? (
          <>
            {/* Search Bar & Advanced Toggle */}
            <div className="mb-6 space-y-4">
              <div className="flex flex-col md:flex-row gap-4 max-w-4xl">
                <div className="relative flex-1">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-white/30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                  </div>
                  <input 
                    type="text"
                    placeholder="Cari judul, genre, atau tahun rilis..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full bg-white/5 border border-white/10 rounded-2xl pl-12 pr-12 py-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:bg-white/10 transition-all text-white placeholder:text-white/20 glass-effect"
                  />
                  {searchTerm && (
                    <button 
                      onClick={() => setSearchTerm('')}
                      className="absolute inset-y-0 right-0 pr-4 flex items-center text-white/30 hover:text-white transition-colors"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                      </svg>
                    </button>
                  )}
                </div>
                
                <button 
                  onClick={() => setIsFilterPanelOpen(!isFilterPanelOpen)}
                  className={`px-6 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 border transition-all glass-effect ${isFilterPanelOpen ? 'border-indigo-500 bg-indigo-500/10 text-indigo-400' : 'border-white/10 text-white/60 hover:text-white'}`}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                  </svg>
                  <span>Filters</span>
                  {hasActiveFilters && (
                    <span className="w-2 h-2 bg-indigo-500 rounded-full animate-pulse"></span>
                  )}
                </button>
              </div>

              {/* Advanced Filter Panel */}
              {isFilterPanelOpen && (
                <div className="p-6 glass-effect border border-white/10 rounded-3xl animate-in fade-in slide-in-from-top-4 duration-300">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {/* Year Range Filter */}
                    <div className="space-y-3">
                      <label className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">Rentang Tahun Rilis</label>
                      <div className="flex items-center gap-3">
                        <input 
                          type="number" 
                          value={minYear} 
                          onChange={(e) => setMinYear(Number(e.target.value))}
                          placeholder="Dari"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-indigo-500/50"
                        />
                        <span className="text-white/20">—</span>
                        <input 
                          type="number" 
                          value={maxYear} 
                          onChange={(e) => setMaxYear(Number(e.target.value))}
                          placeholder="Ke"
                          className="w-full bg-white/5 border border-white/10 rounded-xl px-3 py-2.5 text-sm focus:outline-none focus:border-indigo-500/50"
                        />
                      </div>
                    </div>

                    {/* Rating Filter */}
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <label className="text-[10px] font-bold text-white/40 uppercase tracking-[0.2em]">Rating Minimum</label>
                        <span className="text-indigo-400 font-bold text-sm">{minRating.toFixed(1)}</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="10" 
                        step="0.5" 
                        value={minRating} 
                        onChange={(e) => setMinRating(parseFloat(e.target.value))}
                        className="w-full h-1.5 bg-white/10 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                      />
                      <div className="flex justify-between text-[10px] text-white/20 font-medium">
                        <span>0.0</span>
                        <span>5.0</span>
                        <span>10.0</span>
                      </div>
                    </div>

                    {/* Reset Actions */}
                    <div className="flex items-end">
                      <button 
                        onClick={resetAdvancedFilters}
                        className="w-full h-11 flex items-center justify-center gap-2 text-xs font-bold uppercase tracking-widest text-red-400/60 hover:text-red-400 hover:bg-red-400/5 rounded-xl border border-red-400/10 transition-all"
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                        Reset Filter
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {selectedGenre && (
                <div className="flex items-center gap-2 animate-in slide-in-from-left-4 duration-300">
                  <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest">Genre Terpilih:</span>
                  <button 
                    onClick={() => setSelectedGenre(null)}
                    className="flex items-center gap-2 bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 px-3 py-1.5 rounded-full text-xs font-bold hover:bg-indigo-500 hover:text-white transition-all group"
                  >
                    {selectedGenre}
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3 group-hover:rotate-90 transition-transform" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                </div>
              )}
            </div>

            {/* Filter & Sort Bar */}
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-10">
              <div className="flex gap-2 p-1 bg-white/5 rounded-2xl w-full md:w-fit border border-white/10 overflow-x-auto no-scrollbar">
                {(['all', 'movie', 'series'] as FilterType[]).map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`flex-1 md:flex-none px-6 py-2 rounded-xl text-sm font-bold capitalize transition-all whitespace-nowrap ${filter === f ? 'bg-white text-black shadow-lg' : 'text-white/40 hover:text-white'}`}
                  >
                    {f === 'all' ? 'Semua' : f === 'movie' ? 'Film' : 'Series'}
                  </button>
                ))}
              </div>

              <div className="relative" ref={dropdownRef}>
                <button 
                  onClick={() => setIsSortDropdownOpen(!isSortDropdownOpen)}
                  className="w-full md:w-auto flex items-center justify-between gap-3 px-5 py-3 bg-white/5 border border-white/10 rounded-2xl hover:bg-white/10 transition-all text-sm font-bold"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-white/30 uppercase tracking-widest text-[10px]">Urut:</span>
                    <span className="text-indigo-400">{sortLabels[sortBy]}</span>
                  </div>
                  <svg xmlns="http://www.w3.org/2000/svg" className={`h-4 w-4 transition-transform duration-300 ${isSortDropdownOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {isSortDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-full md:w-56 glass-effect rounded-2xl border border-white/10 shadow-2xl z-50 overflow-hidden animate-in fade-in zoom-in-95 duration-200">
                    {(['watched', 'release', 'rating', 'title'] as SortType[]).map((s) => (
                      <button
                        key={s}
                        onClick={() => {
                          setSortBy(s);
                          setIsSortDropdownOpen(false);
                        }}
                        className={`w-full text-left px-5 py-4 text-sm font-bold flex items-center justify-between transition-all hover:bg-white/5 ${sortBy === s ? 'text-indigo-400 bg-indigo-500/5' : 'text-white/60'}`}
                      >
                        {sortLabels[s]}
                        {sortBy === s && (
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        )}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* User Movie List */}
            <section>
              <div className="flex items-center justify-between mb-8">
                <h2 className="text-2xl font-bold flex flex-wrap items-center gap-3 capitalize">
                  {searchTerm ? `Hasil: "${searchTerm}"` : (filter === 'all' ? 'Koleksi Saya' : filter === 'movie' ? 'Film Saya' : 'Series Saya')}
                  {selectedGenre && <span className="text-indigo-400">({selectedGenre})</span>}
                  <span className="text-sm font-normal text-white/30 bg-white/5 px-2 py-0.5 rounded-lg border border-white/5">
                    {filteredMovies.length}
                  </span>
                </h2>
              </div>

              {filteredMovies.length > 0 ? (
                <motion.div 
                  layout
                  className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 lg:gap-8"
                >
                  <AnimatePresence mode="popLayout">
                    {filteredMovies.map((movie, index) => (
                      <motion.div
                        key={movie.id}
                        layout
                        initial={{ opacity: 0, scale: 0.8, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.8, transition: { duration: 0.2 } }}
                        transition={{ 
                          opacity: { duration: 0.2 },
                          layout: { type: "spring", stiffness: 300, damping: 30, mass: 1 },
                          delay: index * 0.05 < 0.5 ? index * 0.05 : 0 // Only stagger first few items
                        }}
                      >
                        <MovieCard 
                          movie={movie} 
                          onEdit={handleEditMovie}
                          onDelete={() => requestDeleteMovie(movie)}
                          onGenreClick={handleGenreClick}
                          onRatingChange={handleQuickRatingChange}
                        />
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </motion.div>
              ) : (
                <div className="h-64 flex flex-col items-center justify-center text-center opacity-30">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-24 w-24 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
                  </svg>
                  <p className="text-xl font-medium italic px-4">
                    {hasActiveFilters ? `Tidak ada judul yang cocok dengan kriteria pencarian.` : `Belum ada ${filter === 'all' ? 'item' : filter} yang di-rating.`}
                  </p>
                  {hasActiveFilters ? (
                    <button onClick={resetAdvancedFilters} className="mt-4 text-indigo-400 font-bold hover:underline">Hapus Semua Filter</button>
                  ) : (
                    <button onClick={() => setIsFormOpen(true)} className="mt-4 text-indigo-400 font-bold hover:underline">Mulai sekarang</button>
                  )}
                </div>
              )}
            </section>
          </>
        ) : (
          <CalendarView 
            movies={movies} 
            onEdit={handleEditMovie} 
            onDelete={requestDeleteMovie} 
            onRatingChange={handleQuickRatingChange}
          />
        )}
      </main>

      {/* Footer Mobile Nav */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 md:hidden w-[90%] max-sm max-w-sm">
        <div className="glass-effect rounded-full px-8 py-4 flex items-center justify-around shadow-2xl border-white/20">
          <button 
            className={`${viewMode === 'grid' ? 'text-indigo-500' : 'text-white/40'}`} 
            onClick={() => {
              setViewMode('grid');
              resetAdvancedFilters();
            }}
          >
             <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
             </svg>
          </button>
          
          <button 
            className={`${viewMode === 'calendar' ? 'text-indigo-500' : 'text-white/40'}`}
            onClick={() => setViewMode('calendar')}
          >
             <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
             </svg>
          </button>

          <button 
            onClick={() => setIsFormOpen(true)}
            className="bg-indigo-600 p-4 rounded-full -mt-12 border-4 border-[#0a0a0a] shadow-xl active:scale-95"
          >
             <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" />
             </svg>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isFormOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
          >
            <AddMovieForm 
              onSave={handleSaveMovie} 
              editMovie={editingMovie}
              onCancel={() => {
                setIsFormOpen(false);
                setEditingMovie(null);
              }} 
            />
          </motion.div>
        )}
      </AnimatePresence>

      <DeleteConfirmModal 
        isOpen={!!itemToDelete}
        title={itemToDelete?.title || ''}
        onConfirm={confirmDelete}
        onCancel={() => setItemToDelete(null)}
      />
    </div>
  );
};

export default App;
