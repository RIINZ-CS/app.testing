
import { Movie } from './types';

export const INITIAL_MOVIES: Movie[] = [
  {
    id: '1',
    title: 'Inception',
    year: 2010,
    watchedYear: 2023,
    genre: ['Sci-Fi', 'Action'],
    poster: 'https://picsum.photos/seed/inception/400/600',
    rating: 9.0,
    type: 'movie'
  },
  {
    id: '2',
    title: 'Breaking Bad',
    year: 2008,
    watchedYear: 2022,
    genre: ['Crime', 'Drama'],
    poster: 'https://picsum.photos/seed/breakingbad/400/600',
    rating: 10.0,
    type: 'series'
  },
  {
    id: '3',
    title: 'The Dark Knight',
    year: 2008,
    watchedYear: 2024,
    genre: ['Action', 'Crime'],
    poster: 'https://picsum.photos/seed/darkknight/400/600',
    rating: 9.5,
    type: 'movie'
  }
];