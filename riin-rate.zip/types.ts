
export interface User {
  username: string;
}

export interface Movie {
  id: string;
  title: string;
  year: number; // Release year
  watchedYear: number; // Year the user watched it
  genre: string[];
  poster: string;
  rating: number; // 0-10
  type: 'movie' | 'series';
}
