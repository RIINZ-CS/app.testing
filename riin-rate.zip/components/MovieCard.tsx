
import React, { useState } from 'react';
import { Movie } from '../types';

interface MovieCardProps {
  movie: Movie;
  onEdit: (movie: Movie) => void;
  onDelete: (id: string) => void;
  onGenreClick: (genre: string) => void;
  onRatingChange?: (id: string, newRating: number) => void;
}

const getGenreColor = (genre: string) => {
  const colors = [
    'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
    'bg-purple-500/20 text-purple-300 border-purple-500/30',
    'bg-pink-500/20 text-pink-300 border-pink-500/30',
    'bg-teal-500/20 text-teal-300 border-teal-500/30',
    'bg-blue-500/20 text-blue-300 border-blue-500/30',
    'bg-amber-500/20 text-amber-300 border-amber-500/30',
    'bg-rose-500/20 text-rose-300 border-rose-500/30',
  ];
  let hash = 0;
  for (let i = 0; i < genre.length; i++) {
    hash = genre.charCodeAt(i) + ((hash << 5) - hash);
  }
  return colors[Math.abs(hash) % colors.length];
};

export const MovieCard: React.FC<MovieCardProps> = ({ movie, onEdit, onDelete, onGenreClick, onRatingChange }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  const renderPlaceholder = () => (
    <div className="absolute inset-0 flex flex-col items-center justify-center p-6 text-center bg-gradient-to-br from-[#1a1a1a] via-[#0f0f0f] to-[#050505]">
      <div className="absolute inset-0 opacity-10">
        <svg width="100%" height="100%" viewBox="0 0 100 100" preserveAspectRatio="none">
          <defs>
            <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5"/>
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
      </div>
      <div className="relative z-10 flex flex-col items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-white/5 border border-white/10 flex items-center justify-center backdrop-blur-md shadow-2xl">
          <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white/20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M7 4v16M17 4v16M3 8h4m10 0h4M3 12h18M3 16h4m10 0h4M4 20h16a1 1 0 001-1V5a1 1 0 00-1-1H4a1 1 0 00-1 1v14a1 1 0 001 1z" />
          </svg>
        </div>
        <div>
          <p className="text-[10px] font-black uppercase tracking-[0.2em] text-white/30 mb-1">Missing Poster</p>
          <p className="text-xs font-bold text-white/60 line-clamp-2 px-2 italic">"{movie.title}"</p>
        </div>
      </div>
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent"></div>
    </div>
  );

  return (
    <div className="group flex flex-col rounded-2xl overflow-hidden glass-effect transition-all duration-500 hover:scale-[1.02] hover:shadow-2xl hover:shadow-indigo-500/20 h-full relative">
      <div className="aspect-[2/3] w-full relative overflow-hidden bg-white/5">
        {!isLoaded && !hasError && (
          <div className="absolute inset-0 flex items-center justify-center z-10">
            <div className="w-full h-full bg-gradient-to-br from-white/10 to-white/[0.02] animate-pulse"></div>
          </div>
        )}

        {hasError ? renderPlaceholder() : (
          <img 
            src={movie.poster} 
            alt={movie.title} 
            onLoad={() => setIsLoaded(true)}
            onError={() => {
              setHasError(true);
              setIsLoaded(true);
            }}
            className={`w-full h-full object-cover transition-transform duration-[600ms] ease-[cubic-bezier(0.33,1,0.68,1)] group-hover:scale-105 ${isLoaded && !hasError ? 'opacity-100' : 'opacity-0'}`}
          />
        )}
        
        {/* Type Badge */}
        <div className={`absolute top-3 left-3 flex flex-col gap-1.5 z-20 transition-opacity duration-500 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
          <div className={`text-[10px] font-black px-2 py-0.5 rounded-md uppercase tracking-wider border border-white/20 shadow-lg w-fit ${movie.type === 'series' ? 'bg-teal-600' : 'bg-indigo-900/80'}`}>
            {movie.type === 'series' ? 'Series' : 'Film'}
          </div>
        </div>
        
        {/* Rating Floating Badge */}
        <div className={`absolute top-3 right-3 bg-black/60 backdrop-blur-md px-2 py-1 rounded-lg border border-white/10 flex items-center gap-1 z-20 transition-opacity duration-500 pointer-events-none ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
          <span className="text-yellow-400 text-sm">★</span>
          <span className="font-bold text-sm">{movie.rating % 1 === 0 ? movie.rating : movie.rating.toFixed(1)}</span>
        </div>

        <div className="absolute inset-0 bg-black/60 flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300 backdrop-blur-[2px] z-30">
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onEdit(movie);
            }}
            className="p-3 bg-white text-black rounded-full hover:bg-indigo-500 hover:text-white transition-all transform translate-y-4 group-hover:translate-y-0 duration-300"
            title="Edit"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
          </button>
          <button 
            onClick={(e) => {
              e.stopPropagation();
              onDelete(movie.id);
            }}
            className="p-3 bg-red-500/20 text-red-500 border border-red-500/30 rounded-full hover:bg-red-500 hover:text-white transition-all transform translate-y-4 group-hover:translate-y-0 duration-300"
            title="Hapus"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      </div>

      <div className="p-4 flex flex-col flex-1 bg-white/[0.02] border-t border-white/5">
        <h3 className="text-sm md:text-base font-bold text-white group-hover:text-indigo-400 transition-colors mb-2 line-clamp-2 min-h-[2.5rem] md:min-h-[3rem] leading-tight">
          {movie.title}
        </h3>
        
        <div className="flex flex-wrap items-center justify-between gap-x-2 gap-y-1 mb-3 mt-auto">
          <span className="text-[10px] text-white/40 font-medium whitespace-nowrap">Rilis: {movie.year}</span>
          <span className="text-[10px] text-indigo-400/80 font-bold whitespace-nowrap">Tonton: {movie.watchedYear}</span>
        </div>
        
        <div className="flex gap-1.5 overflow-hidden flex-wrap">
          {movie.genre.map(g => (
            <button 
              key={g} 
              onClick={(e) => {
                e.stopPropagation();
                onGenreClick(g);
              }}
              className={`text-[9px] px-2 py-0.5 rounded-full border uppercase font-bold tracking-tighter transition-all hover:scale-110 active:scale-95 ${getGenreColor(g)}`}
            >
              {g}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
