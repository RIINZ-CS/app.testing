
import React, { useState, useEffect, useRef } from 'react';
import { Movie } from '../types';
import { searchMovieMetadata } from '../services/geminiService';

interface AddMovieFormProps {
  onSave: (movie: Omit<Movie, 'id'>) => void;
  editMovie?: Movie | null;
  onCancel: () => void;
}

export const AddMovieForm: React.FC<AddMovieFormProps> = ({ onSave, editMovie, onCancel }) => {
  const [title, setTitle] = useState('');
  const [type, setType] = useState<'movie' | 'series'>('movie');
  const [rating, setRating] = useState(5.0);
  const [year, setYear] = useState(new Date().getFullYear());
  const [watchedYear, setWatchedYear] = useState(new Date().getFullYear());
  const [genre, setGenre] = useState('');
  const [poster, setPoster] = useState('');
  
  // AI Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (editMovie) {
      setTitle(editMovie.title);
      setType(editMovie.type);
      setRating(editMovie.rating);
      setYear(editMovie.year);
      setWatchedYear(editMovie.watchedYear || new Date().getFullYear());
      setGenre(editMovie.genre.join(', '));
      setPoster(editMovie.poster);
    }
  }, [editMovie]);

  const handleMagicSearch = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    setSearchError('');
    
    try {
      const data = await searchMovieMetadata(searchQuery);
      if (data) {
        setTitle(data.title);
        setType(data.type);
        setYear(data.year);
        setGenre(data.genre.join(', '));
        setPoster(data.poster);
        setSearchQuery('');
      } else {
        setSearchError('Tidak dapat menemukan data film. Silakan isi manual.');
      }
    } catch (err) {
      setSearchError('Terjadi kesalahan saat mencari. Silakan coba lagi.');
    } finally {
      setIsSearching(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setPoster(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      title,
      type,
      year,
      watchedYear,
      genre: genre.split(',').map(g => g.trim()).filter(g => g !== ''),
      rating: Number(rating),
      poster: poster || `https://picsum.photos/seed/${title.toLowerCase().replace(/\s/g, '')}/400/600`
    });
    onCancel();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl overflow-y-auto">
      <form 
        onSubmit={handleSubmit}
        className="w-full max-w-5xl glass-effect rounded-[2.5rem] p-6 md:p-10 border border-white/20 shadow-2xl flex flex-col md:flex-row gap-8 md:gap-12 my-auto relative overflow-hidden"
      >
        {/* Magic Search Overlay for Loading */}
        {isSearching && (
          <div className="absolute inset-0 z-[60] bg-black/60 backdrop-blur-md flex flex-col items-center justify-center text-center animate-in fade-in duration-300">
            <div className="w-20 h-20 relative">
              <div className="absolute inset-0 border-4 border-indigo-500/20 rounded-full"></div>
              <div className="absolute inset-0 border-4 border-transparent border-t-indigo-500 rounded-full animate-spin"></div>
              <div className="absolute inset-2 border-4 border-transparent border-b-purple-500 rounded-full animate-spin-slow"></div>
            </div>
            <p className="mt-6 text-xl font-black italic tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 animate-pulse">
              MENGAMBIL DATA AI...
            </p>
            <p className="text-white/40 text-xs mt-2 font-medium">Mencari detail resmi & poster terbaik</p>
          </div>
        )}

        {/* Left Side: Poster Preview & Upload */}
        <div className="w-full md:w-1/3 flex flex-col gap-4">
          <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] mb-1">Visual Poster</label>
          <div className="relative aspect-[2/3] rounded-3xl overflow-hidden bg-white/5 border border-white/10 flex items-center justify-center group shadow-2xl">
            {poster ? (
              <img src={poster} alt="Preview" className="w-full h-full object-cover" />
            ) : (
              <div className="text-center p-6 opacity-30">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                <p className="text-xs font-bold uppercase tracking-widest">Belum Ada Gambar</p>
              </div>
            )}
            <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3 backdrop-blur-sm">
               <button 
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="bg-white text-black p-3 rounded-full hover:bg-indigo-500 hover:text-white transition-all transform hover:scale-110 active:scale-95"
               >
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM6.293 6.707a1 1 0 010-1.414l3-3a1 1 0 011.414 0l3 3a1 1 0 01-1.414 1.414L11 5.414V13a1 1 0 11-2 0V5.414L7.707 6.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
                 </svg>
               </button>
               {poster && (
                 <button 
                  type="button"
                  onClick={() => setPoster('')}
                  className="bg-red-500 text-white p-3 rounded-full hover:bg-red-600 transition-all transform hover:scale-110 active:scale-95"
                 >
                   <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                   </svg>
                 </button>
               )}
            </div>
          </div>
          
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />
          
          <div className="mt-2">
            <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest mb-2 ml-1">Atau Gunakan Link Poster</label>
            <input 
              type="text" 
              value={poster.startsWith('data:') ? '' : poster}
              onChange={(e) => setPoster(e.target.value)}
              placeholder="https://images.com/poster.jpg"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-xs focus:outline-none focus:border-indigo-500/50 transition-all placeholder:text-white/10"
            />
          </div>
        </div>

        {/* Right Side: AI Search & Form Details */}
        <div className="flex-1 flex flex-col gap-6">
          <div className="flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <h2 className="text-4xl font-black italic tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white via-indigo-400 to-purple-400">
                {editMovie ? 'EDIT CONTENT' : 'ADD CONTENT'}
              </h2>
              <button 
                type="button" 
                onClick={onCancel}
                className="p-2 text-white/20 hover:text-white transition-colors"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* AI MAGIC SEARCH BAR */}
            {!editMovie && (
              <div className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-2xl blur opacity-20 group-hover:opacity-40 transition duration-500"></div>
                <div className="relative flex items-center bg-[#0d0d0d] rounded-2xl border border-white/10 overflow-hidden">
                  <input 
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), handleMagicSearch())}
                    placeholder="Cari otomatis (contoh: 'Inception' atau 'One Piece')..."
                    className="flex-1 bg-transparent px-5 py-4 text-sm focus:outline-none placeholder:text-white/20"
                  />
                  <button
                    type="button"
                    onClick={handleMagicSearch}
                    disabled={!searchQuery.trim() || isSearching}
                    className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-4 text-xs font-black uppercase tracking-widest transition-all disabled:opacity-50 flex items-center gap-2"
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M11.3 1.047a1 1 0 01.897.447l1.28 2.56 2.56 1.28a1 1 0 010 1.78l-2.56 1.28-1.28 2.56a1 1 0 01-1.78 0l-1.28-2.56-2.56-1.28a1 1 0 010-1.78l2.56-1.28 1.28-2.56a1 1 0 01.897-.447zM10 13a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1z" clipRule="evenodd" />
                    </svg>
                    Magic Search
                  </button>
                </div>
                {searchError && <p className="mt-2 text-[10px] text-red-400 font-bold uppercase tracking-widest ml-1">{searchError}</p>}
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="md:col-span-2 space-y-2">
              <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] ml-1">Judul Resmi</label>
              <input 
                type="text" required value={title} onChange={(e) => setTitle(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:border-indigo-500/50 transition-all text-xl font-bold"
                placeholder="Judul Film atau Series..."
              />
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] ml-1">Kategori</label>
              <div className="flex p-1 bg-white/5 rounded-2xl border border-white/10 h-[60px]">
                <button 
                  type="button"
                  onClick={() => setType('movie')}
                  className={`flex-1 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${type === 'movie' ? 'bg-indigo-600 text-white shadow-lg' : 'text-white/30 hover:text-white'}`}
                >
                  Film
                </button>
                <button 
                  type="button"
                  onClick={() => setType('series')}
                  className={`flex-1 rounded-xl text-xs font-black uppercase tracking-widest transition-all ${type === 'series' ? 'bg-teal-600 text-white shadow-lg' : 'text-white/30 hover:text-white'}`}
                >
                  Series
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] ml-1">Rating Personal (0-10)</label>
              <div className="relative">
                <input 
                  type="number" min="0" max="10" step="0.1" value={rating} onChange={(e) => setRating(parseFloat(e.target.value) || 0)}
                  className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:border-indigo-500/50 transition-all text-xl font-black text-indigo-400"
                />
                <span className="absolute right-5 top-1/2 -translate-y-1/2 text-white/20 font-black">/ 10</span>
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] ml-1">Tahun Rilis</label>
              <input 
                type="number" value={year} onChange={(e) => setYear(Number(e.target.value))}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:border-indigo-500/50"
              />
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] ml-1">Tahun Ditonton</label>
              <input 
                type="number" value={watchedYear} onChange={(e) => setWatchedYear(Number(e.target.value))}
                className="w-full bg-white/5 border border-indigo-500/20 rounded-2xl px-5 py-4 focus:outline-none focus:border-indigo-500/50"
              />
            </div>

            <div className="md:col-span-2 space-y-2">
              <label className="block text-[10px] font-black text-white/40 uppercase tracking-[0.2em] ml-1">Genre (Pisahkan dengan koma)</label>
              <input 
                type="text" value={genre} onChange={(e) => setGenre(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:border-indigo-500/50 transition-all"
                placeholder="Contoh: Action, Sci-Fi, Thriller"
              />
            </div>
          </div>

          <div className="flex gap-4 pt-4 mt-auto">
            <button 
              type="button" 
              onClick={onCancel} 
              className="flex-1 bg-white/5 text-white/40 py-5 rounded-3xl font-black uppercase tracking-widest hover:bg-white/10 border border-white/5 transition-all text-xs"
            >
              Batal
            </button>
            <button 
              type="submit"
              className={`flex-[2] text-white py-5 rounded-3xl font-black uppercase tracking-[0.2em] text-xs hover:opacity-90 transition-all shadow-2xl active:scale-[0.98] ${type === 'series' ? 'bg-teal-600 shadow-teal-500/20' : 'bg-indigo-600 shadow-indigo-500/20'}`}
            >
              {editMovie ? 'Perbarui Data' : 'Simpan Koleksi'}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
