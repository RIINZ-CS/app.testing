
import React, { useState } from 'react';

interface LoginProps {
  onLogin: (username: string) => void;
}

type LoginMethod = 'email' | 'phone';

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [method, setMethod] = useState<LoginMethod>('email');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleGoogleLogin = () => {
    setIsSubmitting(true);
    // Simulasi login Google
    setTimeout(() => {
      onLogin("Google User");
    }, 1000);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulasi login
    setTimeout(() => {
      if (method === 'email' && email) {
        onLogin(email.split('@')[0]);
      } else if (method === 'phone' && phone) {
        onLogin(`User ${phone.slice(-4)}`);
      }
      setIsSubmitting(false);
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-[#050505] overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-indigo-600/10 blur-[120px] rounded-full animate-pulse"></div>
      <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-purple-600/10 blur-[120px] rounded-full"></div>
      
      <div className="relative w-full max-w-md px-6 animate-in fade-in zoom-in-95 duration-700">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-black italic tracking-tighter text-white mb-2">
            <span className="text-indigo-500">RIIN</span>RATE
          </h1>
          <p className="text-white/40 text-[10px] uppercase tracking-[0.4em] font-bold">Personal Movie Vault</p>
        </div>

        <div className="glass-effect rounded-[2.5rem] p-8 md:p-10 border border-white/10 shadow-2xl relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent"></div>
          
          {/* Google Login Button */}
          <button 
            onClick={handleGoogleLogin}
            disabled={isSubmitting}
            className="w-full bg-white text-black py-4 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-gray-100 transition-all active:scale-[0.98] mb-6 shadow-xl"
          >
            <svg width="20" height="20" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Masuk dengan Google
          </button>

          <div className="flex items-center gap-4 mb-6">
            <div className="flex-1 h-px bg-white/10"></div>
            <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest">atau gunakan</span>
            <div className="flex-1 h-px bg-white/10"></div>
          </div>

          {/* Tab Selector */}
          <div className="flex p-1 bg-white/5 rounded-2xl border border-white/5 mb-6">
            <button 
              onClick={() => setMethod('email')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${method === 'email' ? 'bg-indigo-600 text-white' : 'text-white/40 hover:text-white'}`}
            >
              Email
            </button>
            <button 
              onClick={() => setMethod('phone')}
              className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all ${method === 'phone' ? 'bg-indigo-600 text-white' : 'text-white/40 hover:text-white'}`}
            >
              Nomor HP
            </button>
          </div>
          
          <form onSubmit={handleSubmit} className="space-y-5">
            {method === 'email' ? (
              <div className="space-y-4 animate-in fade-in slide-in-from-left-4 duration-300">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest ml-1">Alamat Email</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-4 flex items-center text-white/20">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 12a4 4 0 10-8 0 4 4 0 008 0zm0 0v1.5a2.5 2.5 0 005 0V12a9 9 0 10-9 9m4.5-1.206a8.959 8.959 0 01-4.5 1.206" />
                      </svg>
                    </span>
                    <input 
                      type="email" 
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="email@contoh.com"
                      className="w-full bg-white/5 border border-white/10 rounded-2xl pl-11 pr-4 py-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:bg-white/10 transition-all text-sm"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest ml-1">Password</label>
                  <input 
                    type="password" 
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:bg-white/10 transition-all text-sm"
                  />
                </div>
              </div>
            ) : (
              <div className="space-y-4 animate-in fade-in slide-in-from-right-4 duration-300">
                <div className="space-y-1.5">
                  <label className="block text-[10px] font-bold text-white/30 uppercase tracking-widest ml-1">Nomor Telepon</label>
                  <div className="flex gap-2">
                    <div className="bg-white/5 border border-white/10 rounded-2xl px-4 py-4 text-sm font-bold text-white/40">
                      +62
                    </div>
                    <input 
                      type="tel" 
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="812 3456 7890"
                      className="flex-1 bg-white/5 border border-white/10 rounded-2xl px-5 py-4 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 focus:bg-white/10 transition-all text-sm"
                    />
                  </div>
                </div>
                <p className="text-[10px] text-white/20 px-1">Kami akan mengirimkan kode verifikasi (OTP) ke nomor ini.</p>
              </div>
            )}
            
            <button 
              type="submit"
              disabled={isSubmitting}
              className={`w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold text-sm hover:bg-indigo-500 transition-all transform active:scale-[0.98] shadow-xl shadow-indigo-600/10 flex items-center justify-center gap-2 ${isSubmitting ? 'opacity-70' : ''}`}
            >
              {isSubmitting ? (
                <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                method === 'email' ? 'Masuk Sekarang' : 'Kirim Kode OTP'
              )}
            </button>
          </form>
          
          <p className="mt-8 text-center text-[10px] text-white/20 uppercase tracking-[0.1em] font-medium">
            Belum punya akun? <span className="text-indigo-400 cursor-pointer hover:underline">Daftar disini</span>
          </p>
        </div>
      </div>
      
      {/* Decorative SVG */}
      <div className="absolute top-10 right-10 opacity-10 pointer-events-none hidden md:block">
        <svg width="150" height="150" viewBox="0 0 150 150" fill="none" xmlns="http://www.w3.org/2000/svg">
          <path d="M75 0V150M0 75H150" stroke="white" strokeWidth="1" />
          <circle cx="75" cy="75" r="74" stroke="white" strokeWidth="1" strokeDasharray="5 5" />
        </svg>
      </div>
    </div>
  );
};
