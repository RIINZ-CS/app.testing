
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Movie } from '../types';
import { MovieCard } from './MovieCard';

interface CalendarViewProps {
  movies: Movie[];
  onEdit: (movie: Movie) => void;
  onDelete: (movie: Movie) => void;
  onRatingChange?: (id: string, newRating: number) => void;
}

export const CalendarView: React.FC<CalendarViewProps> = ({ movies, onEdit, onDelete, onRatingChange }) => {
  const [selectedGenre, setSelectedGenre] = useState<string | null>(null);
  const [selectedYear, setSelectedYear] = useState<number | null>(null);

  const watchedYears = useMemo(() => {
    const years = Array.from(new Set(movies.map(m => m.watchedYear || m.year))).sort((a, b) => b - a);
    return years;
  }, [movies]);

  const allGenres = useMemo(() => {
    const genres = new Set<string>();
    movies.forEach(m => m.genre.forEach(g => genres.add(g)));
    return Array.from(genres).sort();
  }, [movies]);

  // Set default year if not selected
  useMemo(() => {
    if (selectedYear === null && watchedYears.length > 0) {
      setSelectedYear(watchedYears[0]);
    }
  }, [watchedYears, selectedYear]);

  const filteredMovies = useMemo(() => {
    return movies.filter(m => {
      const year = m.watchedYear || m.year;
      const matchesYear = year === selectedYear;
      const matchesGenre = !selectedGenre || m.genre.includes(selectedGenre);
      return matchesYear && matchesGenre;
    }).sort((a, b) => (b.rating || 0) - (a.rating || 0));
  }, [movies, selectedYear, selectedGenre]);

  return (
    <div className="animate-in fade-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex flex-col gap-8">
        <div className="flex flex-col gap-6">
          <div className="flex items-center justify-between">
            <h2 className="text-3xl font-black text-white flex items-center gap-3">
              <span className="text-indigo-500">Kalender</span> Riwayat
            </h2>
            <div className="hidden md:block text-xs font-bold text-white/30 uppercase tracking-[0.2em]">
              Arsip Tontonan Tahunan
            </div>
          </div>

          {/* Horizontal Year Strip */}
          <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2">
            {watchedYears.map(year => (
              <button
                key={year}
                onClick={() => {
                  setSelectedYear(year);
                }}
                className={`flex-shrink-0 px-8 py-4 rounded-2xl font-black text-xl transition-all border-2 ${
                  selectedYear === year 
                  ? 'bg-indigo-600 border-indigo-500 text-white shadow-xl shadow-indigo-600/20 scale-105' 
                  : 'bg-white/5 border-white/5 text-white/40 hover:text-white hover:bg-white/10'
                }`}
              >
                {year}
              </button>
            ))}
            {watchedYears.length === 0 && (
              <div className="text-white/20 italic p-4">Belum ada data riwayat menonton...</div>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar Filters */}
          <div className="lg:col-span-1 space-y-6">
            <div className="glass-effect rounded-3xl p-6 border border-white/10 sticky top-28">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xs font-black text-white uppercase tracking-widest">Filter Genre</h3>
                {selectedGenre && (
                  <button 
                    onClick={() => setSelectedGenre(null)}
                    className="text-[10px] text-red-400 font-bold hover:underline"
                  >
                    Hapus
                  </button>
                )}
              </div>
              <div className="flex flex-wrap gap-2 max-h-48 lg:max-h-none overflow-y-auto no-scrollbar">
                {allGenres.map(genre => (
                  <button
                    key={genre}
                    onClick={() => setSelectedGenre(selectedGenre === genre ? null : genre)}
                    className={`px-3 py-1.5 rounded-full text-[11px] font-bold border transition-all ${
                      selectedGenre === genre
                      ? 'bg-indigo-600 border-indigo-500 text-white'
                      : 'bg-white/5 border-white/10 text-white/40 hover:text-white hover:border-white/30'
                    }`}
                  >
                    {genre}
                  </button>
                ))}
              </div>
              
              <div className="mt-8 pt-6 border-t border-white/5">
                <div className="flex flex-col gap-1">
                  <span className="text-[10px] font-bold text-white/20 uppercase">Ringkasan {selectedYear}</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-indigo-400">{filteredMovies.length}</span>
                    <span className="text-xs font-bold text-white/40">Item Selesai</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Results Grid */}
          <div className="lg:col-span-3">
            {filteredMovies.length > 0 ? (
              <motion.div 
                layout
                className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                <AnimatePresence mode="popLayout">
                  {filteredMovies.map((movie) => (
                    <motion.div 
                      key={movie.id}
                      layout
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.9 }}
                      transition={{ 
                        opacity: { duration: 0.2 },
                        layout: { type: "spring", stiffness: 300, damping: 30 } 
                      }}
                    >
                      <MovieCard 
                        movie={movie} 
                        onEdit={onEdit} 
                        onDelete={() => onDelete(movie)} 
                        onGenreClick={(g) => setSelectedGenre(g)} 
                        onRatingChange={onRatingChange}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </motion.div>
            ) : (
              <div className="h-64 glass-effect rounded-3xl flex flex-col items-center justify-center text-center p-8 border border-white/10">
                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center mb-4 text-white/10">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                </div>
                <h4 className="text-lg font-bold text-white/40 mb-1">Kosong</h4>
                <p className="text-sm text-white/20 max-w-xs">
                  {selectedGenre 
                    ? `Tidak ditemukan film "${selectedGenre}" di tahun ${selectedYear}.` 
                    : `Data tontonan untuk tahun ${selectedYear} belum tersedia.`}
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
