
import React from 'react';

interface DeleteConfirmModalProps {
  isOpen: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  title: string;
}

export const DeleteConfirmModal: React.FC<DeleteConfirmModalProps> = ({ isOpen, onConfirm, onCancel, title }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="w-full max-w-md glass-effect rounded-[2rem] p-8 border border-white/10 shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </div>
          
          <h2 className="text-2xl font-bold mb-2">Hapus Item?</h2>
          <p className="text-white/60 mb-8 leading-relaxed">
            Apakah kamu yakin ingin menghapus <span className="text-white font-bold italic">"{title}"</span> dari koleksi rating kamu? Tindakan ini tidak bisa dibatalkan.
          </p>

          <div className="flex w-full gap-4">
            <button 
              onClick={onCancel}
              className="flex-1 bg-white/5 hover:bg-white/10 text-white/70 py-4 rounded-2xl font-bold transition-all border border-white/5"
            >
              Batal
            </button>
            <button 
              onClick={onConfirm}
              className="flex-1 bg-red-600 hover:bg-red-500 text-white py-4 rounded-2xl font-bold transition-all shadow-lg shadow-red-600/20"
            >
              Ya, Hapus
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
